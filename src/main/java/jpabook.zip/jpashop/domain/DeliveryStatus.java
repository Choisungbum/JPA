package jpabook.jpashop.domain;

public class DeliveryStatus {
}
